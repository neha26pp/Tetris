package Views;

import Controllers.TetrisController;
import Models.Tetronimo;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Board.java
 *
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class to contain the GUI for the tetris game
 *
 */
public class Board extends JPanel  {


    static final int cellSize = 20; //size of each cell on the grid/board
    static final int rows = 24; //constant for the number of rows on the board
    static final int cols = 10; //constant for the number of columns on the board
    public Color[][]background; //array that stores the color of the cells of the board



    private final TetrisController CONTROLLER ; //instantiating a controller object

    //swing components to be added to the frame
    public  JLabel scoreLabel = new JLabel("SCORE");
    JButton quitButton = new JButton("QUIT");



    /**
     * Constructor that initializes the components and starts the game
     * @param frame JFrame on to which all components are appended
     */
    public Board(JFrame frame){

        //to ensure that controller can communicate with the board
        this.CONTROLLER = new TetrisController( this );

        this.background = new Color[rows][cols];

        this.keyBoardControls(); //method that changes the orientation of tetronimos based on the keys pressed


        TetrisThread THREAD = new TetrisThread(this, CONTROLLER);
        THREAD.start(); //starts the thread responsible for spawning the tetronimos at regular intervals
        //setting particulars of the components

        scoreLabel.setBounds(600,110,150,20);
        frame.add(scoreLabel);
        //scoreLabel.setVisible(true);

        quitButton.setText("Quit"); //text displayed on button

        quitButton.setBounds(50,550,150,20); //size and position of button

        quitButton.addActionListener(new QuitListener()); //method to exit the gui when button is pressed

        frame.add(quitButton); //appending button to the frame

        //quitButton.setVisible(true);






    }

    public Tetronimo block; //instance of a tetronimo
    public Tetronimo nextPiece; //falling piece

    /**
     * Method that begins the game and spawns tetronimos
     */
    public void run(){

        this.block = this.CONTROLLER.getNextTetronimo(); //gets the next random tetronimo from the controller

        this.block.spawn(cols); //spawns the tetronimos

        //nextPiece = this.block;
        //nextPiece.nextPiece(nextPiece);

        //nextPiece.spawn(cols);



    }

    /**
     * Method to check if tetronimo is out of bounds
     * @return boolean
     */
    public boolean tetronimoOutOfBounds(){
        //method called in Thread class since it's responsible for moving the pieces down
        //if top row is not in the board, the tetronimo is out of bounds
        //i.e tetronimo's y position is < 0
        if(block.getY() < 0){
            block = null;
            return true;
        }
        return false;
    }

    /**
     * Method to move the tetronimo down
     * @return boolean
     */
    public boolean moveTetronimoDown(){

        //out of bounds should be checked before tetronimo is moved to background
        if(!CONTROLLER.tetronimoLanded()){

            return false;
        }

        block.moveDown(); //if tetronimo is within bounds then it moves down

        repaint();
        return true;
    }



    /**
     * A method to store each block of the board into an array
     * Draws the foreground
     *
     */
    private void drawBlock(Graphics g) {


        for(int i = 0; i < block.getHeight(); i++){

            for (int j = 0; j < block.getWidth(); j++){

                //check if block is colored
                if(block.getShape()[i][j] == 1){

                    //position of tetronimo
                    int x = (block.getX() + j) * cellSize;
                    int y = (block.getY() + i) * cellSize;

                    drawBoardBlock(g, block.getColor(), x, y);
                }
            }
        }


    }

    /**
     * Method to set the background of the tetris board
     *
     * @param g Graphics object
     */
    private void drawBackground(Graphics g){

        Color color;

        for(int i = 0; i < rows; i++){

            for(int j = 0; j < cols; j++){

                color = background[i][j]; //background array

                if(color != null){

                    //position of tetronimo
                    int x = j * cellSize;
                    int y = i * cellSize;

                    drawBoardBlock(g,color,x,y);


                }
            }
        }
    }

    /**
     * Method to draw a block given its parameters
     *
     * @param g Graphics object
     * @param color Color of  block
     * @param x x position
     * @param y y position
     */
    private void drawBoardBlock(Graphics g, Color color, int x, int y){
        g.setColor(color);
        g.fillRect(x , y, cellSize, cellSize);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, cellSize, cellSize  );
    }

    /**
     * Method to store all the blocks that have reached the bottom of the grid in the background
     */
    public void moveTetronimoToBackground(){
        int[][] shape = block.getShape();
        int h = block.getHeight();
        int w = block.getWidth();

        int xPos = block.getX();
        int yPos = block.getY();

        Color color = block.getColor();

        for(int i = 0; i < h ; i++){

            for(int j = 0; j < w; j++){

                //if the block is colored
                if(shape[i][j] == 1) {

                    //set corresponding element of background to that color
                    background[i + yPos][j + xPos] = color;
                }
            }
        }

    }

    /**
     * Method to set the colors of all the boxes on the grid
     * @param g object of Graphics class
     */
    protected void paintComponent(Graphics g){
        super.paintComponent(g);

       for(int i = 0; i < rows ; i++){
           for(int j = 0; j < cols; j++){

               g.drawRect(j*cellSize, i*cellSize, cellSize, cellSize  );
           }
       }

        drawBackground(g);
        drawBlock(g);



    }


    /**
     * Method to make the tetronimos react to keyboard input
     * Uses key bindings
     */
    private void keyBoardControls(){
        //key bindings

        //contains keystrokes
        InputMap im = this.getInputMap();

        //contains action performed respective to keystroke
        ActionMap am = this.getActionMap();

        //different keys pressed
        im.put(KeyStroke.getKeyStroke("RIGHT"),"right");
        im.put(KeyStroke.getKeyStroke("LEFT"),"left");
        im.put(KeyStroke.getKeyStroke("UP"),"up");
        im.put(KeyStroke.getKeyStroke("DOWN"),"down");

        am.put("right", new AbstractAction() {
            /**
             * method to shift the teronimo to the right
             * @param e when RIGHT key pressed
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                if(block == null) return;
                if(!CONTROLLER.checkRight())return;

                block.shiftRight();
                repaint();
            }
        });
        am.put("left", new AbstractAction() {
            /**
             * method to shift the teronimo to the left
             * @param e when LEFT key pressed
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                if(block == null) return;
                if(!CONTROLLER.checkLeft())return;

                block.shiftLeft();
                repaint();
            }
        });
        am.put("up", new AbstractAction() {
            /**
             * method to rotate the tetronimo
             * @param e when UP key pressed
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                if(block == null) return;
                block.rotate();

                if(block.getLeftEdge() < 0) block.setX(0); //if left edge goes out of bounds
                if(block.getRightEdge() >= cols) block.setX(cols - block.getWidth()); //if right edge goes out of bounds
                if(block.getBottomEdge() >= rows) block.setY(rows - block.getHeight()); //if bottom edge goes out of bounds

                repaint();
            }
        });
        am.put("down", new AbstractAction() {
            /**
             * method to shift the teronimo down
             * @param e when DOWN key pressed
             */
            @Override
            public void actionPerformed(ActionEvent e) {

                if(block == null) return;
                if(!CONTROLLER.tetronimoLanded())return;

                CONTROLLER.dropBlock();

            }
        });






    }



}
