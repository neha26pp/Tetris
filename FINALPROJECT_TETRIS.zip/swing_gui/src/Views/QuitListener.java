package Views;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * QuitListener.java
 *
 * A class that implements the interface for receiving action events
 * The GUI exits when quit button is pressed
 */
public class QuitListener implements ActionListener {
    /**
     *
     * @param e component-defined action occurred, here, pressing of the quit button
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        //exit the GUI and program
        System.exit(0);
    }
}
