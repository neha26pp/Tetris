package Views;


import Controllers.TetrisController;

/**
 * TetrisThread.java
 *
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * A thread class to have the tetronimos drop at regular time intervals
 * Extends the Thread class
 */
public class TetrisThread extends Thread{

    private final Board board; //tetris board object
    private final TetrisController controller; //tetris controller object
    private int score; //keep track of player's score

    /**
     * Constructor to initialize board and controller objects
     * @param board : Views.Board object
     * @param controller : Controllers.TetrisController object
     */
    public TetrisThread(Board board, TetrisController controller){
        this.board = board;
        this.controller = controller;
    }

    /**
     * Method to start game
     */
    @Override
    public void run() {

        //infinite loop

        while(true){

            board.run(); //starts the game



            while( board.moveTetronimoDown()){
                try {


                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


            if(board.tetronimoOutOfBounds()){
                //when game is over
                board.quitButton.setText("GAME OVER! QUIT?");
                break;

            }else{
                    board.moveTetronimoToBackground(); //stores the tetronimo back into background array
                    score += controller.clearLines(); //increment the score
                    controller.updateScore(score);



            }

        }

    }
}
