package Models;

/**
 * TShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for TShape tetronimo inherits Tetronimo
 */
public class TShape extends Tetronimo{
    /**
     * Constructor to initialize shape  of tetronimo
     *
     */
    public TShape() {
        super(new int[][]{{1,1,1}, {0,1,0}});
    }
}
