package Models;

/**
 * OShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for oShape tetronimo inherits Tetronimo
 */
public class OShape extends Tetronimo{

    /**
     * Constructor to initialize shape of tetronimo
     */
    public OShape(){
        super(new int[][]{{1,1}, {1,1}});

    }
}
