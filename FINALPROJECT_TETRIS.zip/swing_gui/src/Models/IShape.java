package Models;

/**
 * IShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for IShape tetronimo inherits Tetronimo
 */
public class IShape extends Tetronimo{
    /**
     * Constructor to initialize shape of tetronimo
     *
     */
    public IShape() {
        super(new int[][]{{1,1,1,1}});
    }

    /**
     * overriden method to modify rotation of IShape
     */
    public void rotate(){

        super.rotate();

        if(this.getWidth() == 1){
            this.setX( this.getX() + 1);
            this.setY( this.getY() - 1);
        }else{
            this.setX( this.getX() - 1);
            this.setY( this.getY() + 1);
        }


    }
}
