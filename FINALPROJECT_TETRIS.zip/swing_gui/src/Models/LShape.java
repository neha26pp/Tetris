package Models;

/**
 * LShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for LShape tetronimo inherits Tetronimo
 */
public class LShape extends Tetronimo{

    /**
     * Constructor to initialize shape  of tetronimo
     */
    public LShape() {

        super(new int[][]{{1,0}, {1,0}, {1,1}});
    }
}
