package Models;

/**
 * JShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for JShape tetronimo inherits Tetronimo
 */
public class JShape extends Tetronimo{
    /**
     * Constructor to initialize shape of tetronimo
     *
     */
    public JShape() {

        super(new int[][]{{0,1}, {0,1}, {1,1}});
    }
}
