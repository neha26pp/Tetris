package Models;

import java.awt.*;
import java.util.Random;

/**
 * Tetronimo.java:
 * An abstract class to model the base capabilities of a tetronimo
 *
 * @author Neha Pandit
 * @version 1.0
 *
 * @see java.awt.Color
 */
public class Tetronimo {

    private int[][] shape; //array that describes shape of tetronimo
    private int[][][] rotations; //array to represent the rotations of the tetronimo
    private Color color; //variable that represents color of tetronimo
    private int x, y; //x and y coordinates of the tetronimo
    protected int currentRotation; //represents the shape that is currently active
    private final Color[] availableColor ={Color.GREEN, Color.BLUE, Color.RED}; //array to store different colors of tetronimo



    /**
     * Constructor to initialize shape and color of tetronimo
     * @param shape shape of tetronimo
     *
     */
    public Tetronimo(int[][]shape){

        this.shape = shape;
        setRotations();
    }

    /**
     * Method to set the different rotations of a tetronimo
     */
    private void setRotations(){
        //4 different rotations of 90-degrees
        this.rotations = new int[4][][];

        for(int i = 0; i < 4; i++){

            //number of rows in rotated array will be equal to number of columns in original array
            //as tetronimo is rotated by 90 degrees
            int r = shape[0].length;
            int c = shape.length;

            rotations[i] = new int[r][c];

            for(int y = 0; y < r; y++){

                for(int x = 0; x < c; x++){

                    //coordinates of newly rotated tetronimo
                    rotations[i][y][x] = shape[c-x-1][y];

                }

            }
            //assign the rotated array to current shape
            shape = rotations[i];
        }
    }




    /**
     * Method to set the original position of tetronimo
     * @param gridWidth width of the board
     */
    public void spawn(int gridWidth){

        Random r = new Random(); //to spawn tetronimo at random locations

        currentRotation = r.nextInt(rotations.length); //randomly rotate the tetronimo
        shape = rotations[currentRotation];

        //height and width depend on shape of block
        y = -getHeight();
        x = r.nextInt(gridWidth - getWidth()); //to ensure that tetronimo is not spawned out of bounds
        color = availableColor[r.nextInt(availableColor.length)]; //randomly choose color for tetronimo



    }

    public void nextPiece(Tetronimo piece){
        y = 12;
        x = 20;
    }


    /**
     * accessor method for private variable shape
     * @return shape of tetris block
     */
    public int[][]getShape(){
        return shape;
    }

    /**
     * accessor method for private variable color
     * @return color of tetris block
     */
    public Color getColor(){
        return color;
    }

    /**
     * accessor method for private variable height
     * @return height of tetris block
     */
    public int getHeight(){
        return shape.length;
    }

    /**
     * accessor method for private variable width
     * @return width of tetris block
     */
    public int getWidth(){
        return shape[0].length;
    }

    /**
     * accessor method for private variable x
     * @return x-offset of tetris block
     */
    public int getX(){
        return x;
    }


    /**
     * accessor method for private variable y
     * @return y-offset of tetris block
     */
    public int getY(){
        return y;
    }

    /**
     * method to shift tetronimo the left
     * decrements the x coordinate
     */
    public void shiftLeft(){
        x--;
    }

    /**
     * method to shift tetronimo to the right
     * increments the x coordinate
     */
    public void shiftRight(){
        x++;
    }

    /**
     * method to rotate the tetronimo
     * keeps track of current rotation
     */
    public void rotate(){

        //once tetronimo reaches the bottom of the board, it shouldn't be rotated
        if(getBottomEdge() != 24 ){
            currentRotation++;
            if(currentRotation > 3){
                currentRotation = 0;
            }
            shape = rotations[currentRotation];
        }



    }

    /**
     * method to move tetronimo down
     * increments the y coordinate
     */
    public void moveDown(){
        y++;
    }

    /**
     * accessor method for bottom of the board
     * @return bottom edge of the board
     */
    public int getBottomEdge(){
        return y + getHeight();
    }

    /**
     * accessor method for left edge of the board
     * @return left edge of the board
     */
    public int getLeftEdge(){
        return x;
    }

    /**
     * accessor method for right edge of the board
     * @return right edge of the board
     */
    public int getRightEdge(){
        return x + getWidth();
    }

    //to ensure that tetronimos don't go out of bounds while rotation:

    /**
     * mutator method to set the x-coordinate to a new y-coordinate
     * to be used when tetronimo goes out of bounds and x-coordinate needs to be adjusted
     * @param newX adjusted x coordinate
     */
    public void setX(int newX){
            x = newX;
    }

    /**
     * setter method to set the y-coordinate to a new y-coordinate
     * to be used when tetronimo goes out of bounds and y-coordinate needs to be adjusted
     * @param newY adjusted y coordinate
     */
    public void setY(int newY){
        y = newY;

    }







}




