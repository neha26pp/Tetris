package Models;

/**
 * ZShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for ZShape tetronimo inherits Tetronimo
 */
public class ZShape extends Tetronimo{

    /**
     * Constructor to initialize shape of tetronimo
     */
    public ZShape(){
        super(new int[][]{{1,1,0}, {0,1,1}});
    }

}
