package Models;

/**
 * SShape.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Class for SShape tetronimo inherits Tetronimo
 */
public class SShape extends Tetronimo{
    /**
     * Constructor to initialize shape  of tetronimo

     */
    public SShape() {
        super(new int[][]{{0,1,1}, {1,1,0}});
    }
}
