import Views.Board;

import javax.swing.*;


/**
 * Tetris.java
 *
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 *
 * Main class responsible for creating the frame, adding the Tetris Board to it
 */
public class Tetris  {


    public static void main(String[] args) {


        //Frame to add all the components on
        JFrame frame = new JFrame();
        frame.setSize(600,600);


        //using inheritance to create a Views.Board object which will be the Tetris Board
        Board board = new Board(frame);

        //appending the board to the frame using the built-in method
        frame.add(board);


        frame.setVisible(true);

        //program exits when the user initiates a "close" on this frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }




}