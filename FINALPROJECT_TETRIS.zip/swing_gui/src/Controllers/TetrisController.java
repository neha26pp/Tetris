package Controllers;

import Models.*;
import Views.Board;
import java.util.Random;

/**
 * TetrisController.java
 * @author NEHA
 * @version 1.0 December 15,2021
 *
 * Controller class that contains the logic of the tetris game
 */
public class TetrisController {

    private final Board BOARD; //Views.Board object
    private Tetronimo[] tetronimos; //array to store available tetronimos
    Tetronimo tetronimo;

    /**
     * Constructor to take in a tetris board so the controller and the board can communicate
     *
     * @param board : Views.Board object
     */
    public TetrisController(Board board) {

        this.BOARD = board;

        //instantiating all 7 tetronimos
        tetronimos = new Tetronimo[]{new IShape(),
                                     new LShape(),
                                     new JShape(),
                                     new OShape(),
                                     new SShape(),
                                     new TShape(),
                                     new ZShape()
        };
    }

    /**
     * Method to randomly generate the next tetronimo
     * @return tetronimo
     */
    public Tetronimo getNextTetronimo(){

        Random r = new Random();

        tetronimo = tetronimos[r.nextInt(tetronimos.length)]; //return random tetronimos to the board

        return tetronimo;
    }




    /**
     * Method to ensure the tetronimo has landed and cannot move further, otherwise moves the tetronimo down accordingly
     * @return boolean
     */
    public boolean tetronimoLanded(){

        //if tetronimo has reached the bottom of the board
        if(BOARD.block.getBottomEdge() == 24){
            return false;
        }

        int[][]shape = BOARD.block.getShape();
        int h = BOARD.block.getHeight();
        int w = BOARD.block.getWidth();

        //tetronimo moves down only if there are no tetronimos immediately below it
        for(int col = 0; col < w; col++){

            for(int row = h-1; row >=0 ; row--){

                //if the block is uncolored
                if(shape[row][col] != 0){

                    int x = col + BOARD.block.getX();
                    int y = row + BOARD.block.getY() +1;
                    if(y < 0) break; //tetronimo is spawn from above the board
                    if(BOARD.background[y][x] != null)return false; //if background is colored
                    break; //terminate the loop

                }

            }
        }
        return true;
    }

    /**
     * Method to drop the tetronimo straight down to the bottom
     */
    public void dropBlock(){

        //if tetronimo is properly located
        while(tetronimoLanded()){
            BOARD.block.moveDown();

        }
        BOARD.repaint();
    }

    /**
     * method to check the left edge
     * @return boolean
     */
    public boolean checkLeft(){

        //if tetronimo is at extreme left of board
        if(BOARD.block.getLeftEdge() == 0){
            return false;
        }
        int[][]shape = BOARD.block.getShape();
        int h = BOARD.block.getHeight();
        int w = BOARD.block.getWidth();

        //tetronimo moves left only if there are no tetronimos immediately to the left of it
        for(int row = 0; row < h; row++){

            for(int col = 0; col <w ; col++){

                //if the block is uncolored
                if(shape[row][col] != 0){

                    int x = col + BOARD.block.getX() - 1;
                    int y = row + BOARD.block.getY() ;
                    if(y < 0) break; //tetronimo is spawn from above the board
                    if(this.BOARD.background[y][x] != null)return false; //if background is colored
                    break; //terminate the loop

                }

            }
        }
        return true;
    }

    /**
     * Method to check right edge
     * @return boolean
     */
    public boolean checkRight(){

        //if the tetronimo has reached extreme right of board
        if(BOARD.block.getRightEdge() == 10){
            return false;
        }

        int[][]shape = BOARD.block.getShape();
        int h = BOARD.block.getHeight();
        int w = BOARD.block.getWidth();

        //tetronimo moves left only if there are no tetronimos immediately to the left of it
        for(int row = 0; row < h; row++){

            for(int col = w-1; true; col--){

                //if the block is uncolored
                if(shape[row][col] != 0){

                    int x = col + BOARD.block.getX() + 1; //check background array to the right of the block
                    int y = row + BOARD.block.getY() ;
                    if(y < 0) break; //tetronimo is spawn from above the board
                    if(this.BOARD.background[y][x] != null)return false; //if background is colored
                    break; //terminate the loop

                }

            }
        }
        return true;
    }

    /**
     * Method to clear completed lines on the board
     */
    public int clearLines(){

        int linesCleared = 0; //counter
        boolean lineFilled;

        //traverse the row backward
        for(int row = 24 -1 ; row >= 0 ; row--){

            lineFilled = true;

            //traverse the columns foward
            for(int col = 0; col < 10; col++){

                if(BOARD.background[row][col] == null){
                    lineFilled= false;
                    break;
                }
            }
            if(lineFilled){

                linesCleared++;
                clearLine(row); //clear the filled line
                shiftLineDown(row); //shift all the elements on the line above to the line below it
                clearLine(0); //for first row

                row++; //when a line is cleared, the line above it is at the same number

                BOARD.repaint();
            }

        }
        return linesCleared;
    }

    /**
     * Method to clear a single line, un-colors the cells
     * @param lineNumber the row number i.e. line which needs to be cleared
     */
    public void clearLine(int lineNumber){

        for(int i = 0; i < 10; i++){

            //makes the cells white
            BOARD.background[lineNumber][i] = null;

        }
    }

    /**
     * Method to shift the line above the cleared line down
     * @param lineNumber the row number i.e. line which needs to be shifted down
     */
    public void shiftLineDown(int lineNumber){

        for(int row = lineNumber; row > 0; row--){

            for(int col = 0; col < 10; col++){

                //elements of background array are set to values of elements immediately above them
                BOARD.background[row][col] = BOARD.background[row-1][col];
            }
        }

    }

    /**
     * Method to update the score based on number of lines cleared
     * @param score
     */
    public void updateScore(int score){

        //if 4 lines are cleared at once
        if(score == 4){
            BOARD.scoreLabel.setText("SCORE: " + 800);
        }
        BOARD.scoreLabel.setText("SCORE: " + score * 100 );

    }




}
